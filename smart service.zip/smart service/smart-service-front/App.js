import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
 import { registerRootComponent } from 'expo';
import HomeScreen from './screen/home';
import SignIn from './screen/SignIn';
import SignUp from './screen/SignUp';
import ActuelPosition from './screen/actuel-position';
import Todo from './screen/toDo';
import Shower from './screen/shower';
import Walk from './screen/walk';
import Sleep from './screen/sleep';
import Eat from './screen/eat';
 import { name as appName } from "./app.json";

export default function App() {
  const Stack=createNativeStackNavigator()
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName='home'>
        <Stack.Screen 
        name="home" 
        component={HomeScreen}
        options={{title :"HOME"}}
          />
        <Stack.Screen 
        name='sign in' 
        component={SignIn}
        options={{title :"Sign In"}}
        />
        <Stack.Screen 
        name='sign up' 
        component={SignUp}
        options={{title :"Sign Up"}}
        />
        <Stack.Screen 
        name='actuel position' 
        component={ActuelPosition}
        options={{title :"Actual Position"}}
        />  
        <Stack.Screen 
        name='todo' 
        component={Todo}
        options={{title :"What you want to do ?"}}
        />  
        <Stack.Screen 
        name='walk' 
        component={Walk}
        options={{title :"Walk ?"}}
        />  
        <Stack.Screen 
        name='sleep' 
        component={Sleep}
        options={{title :"Sleep ?"}}
        />  
        <Stack.Screen 
        name='shower' 
        component={Shower}
        options={{title :"Shower ?"}}
        />  
        <Stack.Screen 
        name='eat' 
        component={Eat}
        options={{title :"Eat ?"}}
        />  
      </Stack.Navigator>
    </NavigationContainer>
  );
}