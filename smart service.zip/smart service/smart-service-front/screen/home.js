import react from "react";
import { StyleSheet, Text, View,Pressable,ImageBackground,Button,Alert} from 'react-native';
import { useNavigation } from "@react-navigation/native";
const HomeScreen=()=>{
    const navigation = useNavigation();
    const image={uri: "https://www.digilor.fr/wp-content/uploads/2020/04/hotel-intelligent-ecran-tactile.png"}
    return(
        <View style={styles.container}>
            <ImageBackground source={image} resizeMode="cover" style={styles.image}>
            <Text style={styles.text}>
                We always strive to improve services to make our customers spend a pleasent and comfortable holiday.
             </Text>
             {/* <View>
            <Pressable> <Text> Sign Up </Text></Pressable>
            <Pressable><Text> Sign Up </Text></Pressable>
             </View> */}
              <View style={styles.fixToText}>
        <Button
          title="Sign up"
          onPress={() => navigation.navigate("sign up")}
        />
        <Button
          title="Sign in"
          onPress={() => navigation.navigate("sign in")}
        />
      </View>
               
               </ImageBackground>  
        </View>
    )
}

const styles =StyleSheet.create({
container:{
    flex: 1,
    // backgroundColor: '#fff',
    // alignItems: 'center',
    // justifyContent: 'center',
    
},
text:{
    padding:100,
    fontSize:25,
    color:"white",
    fontWeight:"bold",
    textAlign: 'center',
    marginVertical: 10,
},
image: {
    flex: 1,
    justifyContent: "center"
  },
  fixToText: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginHorizontal: 80,
    borderRadius:3
  }
})
export default HomeScreen