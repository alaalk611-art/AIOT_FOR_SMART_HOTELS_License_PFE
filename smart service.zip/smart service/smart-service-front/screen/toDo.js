import React from "react";
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    onPress,
    Linking,
    Button,
    StatusBar,
    TouchableOpacity,
    SafeAreaView,
    FlatList
    
  } from "react-native";
  import { useNavigation } from "@react-navigation/native";
  


  const DATA = [
    {
      title: 'Sleep',
      id:1,
      link:"sleep"

    },
    {
        title: 'Have a shower',
        id:2,
        link:"shower"
  
    },
    {
     
        title: 'Eat',
        id:3,
        link:"eat"
  
    },
    {
        title: ' Have a Walk',
        id:4,
        link:"walk"
  
      },
  ];
  const Todo=()=>{
    let navigation=useNavigation()
    const Item = ({ title ,link}) => (
      <View style={styles.item}>
        <Text style={styles.title} onPress={()=>navigation.navigate(link)}>{title}</Text>
      </View>
    );
  
  
  
      const renderItem = ({ item }) => (
          <Item title={item.title} link={item.link} key={item.id}/>
        );
      
        return (
          <SafeAreaView style={styles.container}>
        <FlatList
          data={DATA}
          renderItem={renderItem}
          keyExtractor={item => item.id}
        />
      </SafeAreaView>
        );
      
     
      
  }
  
      const styles = StyleSheet.create({
          container: {
              flex: 1,
              marginTop: StatusBar.currentHeight || 0,
            },
            item: {
              backgroundColor: '#9999FF',
              padding: 20,
              marginVertical: 8,
              marginHorizontal: 16,
            },
            title: {
              fontSize: 32,
            },
        })
      
  

  export default Todo