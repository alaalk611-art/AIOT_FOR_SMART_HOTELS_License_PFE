import React,{useState,useEffect} from "react";
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    onPress,
    Linking,
    Button,
    StatusBar,
    TouchableOpacity,
    SafeAreaView,
    FlatList
    
  } from "react-native";
  import { SCLAlert, SCLAlertButton} from 'react-native-scl-alert'

  import { useNavigation } from "@react-navigation/native";
  import axios from "axios"
  const Eat =()=>{
    const [data, setData] = useState([]);
    const [show,setShow]=useState(false)
    const [mes,setMes]=useState("")
    // handleOpen = () => {
    //     setShow(true)
    //   }
    
    //   handleClose = () => {
    //     setShow(false)
    //   }

    useEffect(() => {
const eat = async() => { await axios.get('http://192.168.1.132:3000/api/eat/get').then((response)=>{
            //    console.log(" hello" + response.data)
            // console.log(data.data);
            //  console.log(response.data);
            // console.log(data);
               setData({data:response.data})
           }).catch((err)=>{
               console.log(err)
               
           })}

            eat() },[])


   
  
    //   const result = await axios(
    //     'http://192.168.1.140:3000/api/eat/get',
    //   );
  
    //   setData(result.data);
    // });
    const Item = ({title,key,message}) => (
        
        <View style={styles.item}>
            <SCLAlert
          theme="info"
          show={show}
          title="Request Answer"
          subtitle={mes}
          cancellable={true}
        //   onRequestClose={setShow(false)}
        >
          <SCLAlertButton theme="info" onPress={()=>{setShow(false)}}>Done</SCLAlertButton>
        </SCLAlert>
          <Text style={styles.title} key={key} onPress={()=>{setShow(true) , setMes(message)}}>{title}</Text>
        </View>
      );
    
    
    
        const renderItem = ({ item }) => (
            <Item title={item.choice} key={item.id_choice} message={item.message}/>
          );
         console.log(data.data)
          return (
            <SafeAreaView style={styles.container}>
          <FlatList
            data={data.data}
            renderItem={renderItem}
            keyExtractor={item => item.id_choice}
          />
        </SafeAreaView>
          )
  }
  const styles = StyleSheet.create({
    container: {
        flex: 1,
        marginTop: StatusBar.currentHeight || 0,
      },
      item: {
        backgroundColor: '#9999FF',
        padding: 20,
        marginVertical: 8,
        marginHorizontal: 16,
      },
      title: {
        fontSize: 15,
      },
  })


  export default Eat