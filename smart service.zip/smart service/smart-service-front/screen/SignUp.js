import React, { useState } from "react";
 import axios from "axios";
// import DatePicker from "@react-native-community/datetimepicker";
 import { useNavigation } from "@react-navigation/native";
import CustomInput from "../components/CustomInput";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  onPress,
  Linking,
  Button
  
} from "react-native";
const SignUp =()=>{
    const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState("");
  const [phone_number, setPhone_number] = useState(null);
  // const [arrived, setArrived] = useState(""); 
  // const [lefted, setLefted] = useState("");
  const navigation = useNavigation();
  const onRegisterPressed = () => {
    axios.post("http://192.168.1.132:3000/api/user/register", {
        username,
        password,
        email,
        phone_number
        // arrived,
        // lefted
        
      }).then(()=>{navigation.navigate("sign in") })
      .catch((err) => console.log(err));
  };
  const onTermpress = () => {
    console.warn("on T press");
  };
  const onPrivacypress = () => {
    console.warn("on P press");
  };
    return(
        <ScrollView>
      <View style={styles.root}>
        <Text style={styles.title}>Create an acount</Text>
        <CustomInput
          placeholder="username"
          value={username}
          setValue={setUsername}
        />
        <CustomInput placeholder="email" value={email} setValue={setEmail} />
        <CustomInput
          placeholder="password"
          value={password}
          setValue={setPassword}
          secureTextEntry={true}
        />
      
        <CustomInput
          placeholder="phone Number"
          value={phone_number}
          setValue={setPhone_number}
        />
       
        {/* <Text>From:</Text> */}
        {/* <DatePicker
          placeholder="select date"
          format="DD-MM-YYYY"
          confirmBtnText="Confirm"
          cancelBtnText="Cancel"
          timeZoneOffsetInMinutes={undefined}
          modalTransparent={false}
          animationType={"fade"}
          display="default"
          style={{ width: 320, backgroundColor: "white" }}
          value={arrived}
          onDateChange={(e)=> setArrived(e)}
        /> */}
       {/* <Text>TO</Text> */}
       {/* <DatePicker
          placeholder="select date"
          format="DD-MM-YYYY"
          confirmBtnText="Confirm"
          cancelBtnText="Cancel"
          timeZoneOffsetInMinutes={undefined}
          modalTransparent={false}
          animationType={"fade"}
          display="default"
          onChange={this.onChangeStart}
          style={{ width: 320, backgroundColor: "white" }}
          value={lefted}
          onDateChange={(e)=> setLefted(e)}
        /> */}
         <Button
        title="Register"
        color="blue"
        onPress={onRegisterPressed}
         />
        <Text style={styles.text}>By registering, you confirm that you accept our
    <Text style={styles.link} onPress={onTermpress}>Terms of Use</Text>
          and
          <Text style={styles.link}  onPress={onPrivacypress}>Privacy Policy</Text>
        </Text>
       
        </View>
    </ScrollView>
    )
}
const styles = StyleSheet.create({
    root: {
      alignItems: "center",
      padding: 20,
    },
    title: {
      fontSize: 40,
      fontWeight: "bold",
      color: "#051C60",
      margin: 10,
    },
    text: {
      color: "gray",
      marginVertical: 10,
    },
    link: {
      color: "#FDB075",
    },
  });
  
export default SignUp