import React, { useState } from "react";
 import axios from "axios";
 import { useNavigation } from "@react-navigation/native";
 import CustomInput from "../components/CustomInput";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  onPress,
  Linking,
  Button
  
} from "react-native";
const SignIn =()=>{
    const [password,setPassword]=useState("");
    const [email, setEmail] = useState("");
    const navigation = useNavigation();
    const onSignInPressed =()=>{
      axios
      .post("http://192.168.1.132:3000/api/user/login", {
        password,
        email
      })
      .then((res)=>{
        if(res.data ==="Email or password is incorrect!"){
          // console.log(data)
          // console.log(res.result)
          console.warn("wrong password or email")
        }else{
  console.log(res.data)
          navigation.navigate("actuel position")
        }
      }).catch((err)=>console.log(err))
   
  
  };
    return(
        <ScrollView>
    <View style={styles.root}>
     
    
    <CustomInput placeholder="email" value={email} setValue={setEmail} />
    <CustomInput
    placeholder="password"
    value={password}
    setValue ={setPassword}
    secureTextEntry={true}
    />
     <Button
        title="Log in"
        color="blue"
        onPress={onSignInPressed}
      />
      <Text style={styles.link}  onPress={()=>navigation.navigate("sign up")}>If you don t have an acount create one</Text>
     </View>
    </ScrollView>
    )
    
}
const styles=StyleSheet.create({
    root :{
      alignItems:'center',
      padding:20
    },
    link: {
        color: "#FDB075",
      }
    })
export default SignIn