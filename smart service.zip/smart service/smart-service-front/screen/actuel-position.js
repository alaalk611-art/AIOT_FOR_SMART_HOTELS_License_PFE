import React from "react";
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    onPress,
    Linking,
    Button,
    StatusBar,
    TouchableOpacity,
    SafeAreaView,
    FlatList
    
  } from "react-native";
  import { useNavigation } from "@react-navigation/native";
  


  const DATA = [
    {
      title: 'Swimming Pool',
    },
    {
    
      title: 'Hotel Reception',
    },
    {
     
      title: 'Hotel lounge',
    },
    {
     
        title: 'My Room',
      },
  ];
 
const ActuelPosition=()=>{
  let navigation=useNavigation()
  const Item = ({ title }) => (
    <View style={styles.item}>
      <Text style={styles.title} onPress={()=>navigation.navigate("todo")}>{title}</Text>
    </View>
  );



    const renderItem = ({ item }) => (
        <Item title={item.title} />
      );
    
      return (
        <SafeAreaView style={styles.container}>
      <FlatList
        data={DATA}
        renderItem={renderItem}
        keyExtractor={item => item.id}
      />
    </SafeAreaView>
      );
    
    
    {/* //         <Button
    //     title="Swimming Pool"
    //     color="red"
    //     style={styles.btn}
    //     // onPress={onSignInPressed}
    //   />
    //   <Button
    //     title="Hotel Reception"
    //     color="yellow"
    //     style={styles.btn}
    //     // onPress={onSignInPressed}
    //   />
    //   <Button
    //     title="Hotel lounge"
    //     // color="green"
    //     style={styles.btn}
    //     // onPress={onSignInPressed}
    //   />
    //   <Button
    //     title="My Room"
    //     // color="blue"
    //     // borderRadius="20"
    //     // size="50"
    //     style={styles.btn}
       
    //     // onPress={onSignInPressed}
    //   /> */}
    
}

    const styles = StyleSheet.create({
        container: {
            flex: 1,
            marginTop: StatusBar.currentHeight || 0,
          },
          item: {
            backgroundColor: '#f9c2ff',
            padding: 20,
            marginVertical: 8,
            marginHorizontal: 16,
          },
          title: {
            fontSize: 32,
          },
      })
    

export default ActuelPosition