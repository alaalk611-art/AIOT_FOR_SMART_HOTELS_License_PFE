const router = require('express').Router();
const showerController=require("../controllers/shower.controller")

router.get("/get",showerController.getShowerchoice)
router.get("/get/:id",showerController.getShoweranswer)




module.exports = router;