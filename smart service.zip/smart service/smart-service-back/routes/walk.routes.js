const router = require('express').Router();
const walkController=require("../controllers/walk.controller")
router.get("/get",walkController.getWalkchoice)
router.get("/get/:id",walkController.getWalkanswer)









module.exports = router;