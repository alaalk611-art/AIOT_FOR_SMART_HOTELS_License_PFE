const router = require('express').Router();
const eatController=require("../controllers/eat.controller")
router.get("/get",eatController.getEatchoice)
router.get("/get/:id",eatController.getEatanswer)


module.exports = router;