const router = require('express').Router();
const sleepController = require("../controllers/sleep.controller")
router.get("/get",sleepController.getSleepchoice)
router.get("/get/:id",sleepController.getSleepchoice)







module.exports = router;