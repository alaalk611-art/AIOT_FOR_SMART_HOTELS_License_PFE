var mysql = require('mysql2');

var db = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : 'root',
  database : 'smart'
});
db.connect(function (err) {
  if (err) {
    return console.error('error: ' + err.message);
  }
  console.log("Database Connected ");
});
module.exports = db;

