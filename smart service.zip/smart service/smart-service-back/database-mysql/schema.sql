DROP DATABASE IF EXISTS smart;

CREATE DATABASE smart;

USE smart ;

CREATE TABLE Users (
  id_User int AUTO_INCREMENT,
  username VARCHAR(200),
  email VARCHAR(200),
  password VARCHAR(200),
  phone_number int,
  PRIMARY KEY (id_User)
);

CREATE TABLE Sleep (
id_choice int AUTO_INCREMENT,
choice VARCHAR (200),
message VARCHAR (200),
PRIMARY KEY (id_choice)
);
CREATE TABLE Shower (
id_choice int AUTO_INCREMENT,
choice VARCHAR (200),
message VARCHAR (200),
PRIMARY KEY (id_choice)
);
CREATE TABLE Eat (
id_choice int AUTO_INCREMENT,
choice VARCHAR (200),
message VARCHAR (200),
PRIMARY KEY (id_choice)
);
CREATE TABLE Walk (
id_choice int AUTO_INCREMENT,
choice VARCHAR (200),
message VARCHAR (200),
PRIMARY KEY (id_choice)
);


/*  Execute this file from the command line by typing:
 *    mysql -u root -p < server/database-mysql/schema.sql
 *  to create the database and the tables.*/
 INSERT INTO Sleep (id_choice, choice, message) VALUES (1, "Close the blinds", "Done, Good night");
 INSERT INTO Sleep (id_choice, choice, message) VALUES (2, "Turn out the lights", "Done, Good night");
 INSERT INTO Sleep (id_choice, choice, message) VALUES (3, "Set an alarm", "Which time do you want");
 INSERT INTO Sleep (id_choice, choice, message) VALUES (4, "Play soft music", "We hope you enjoy our music playlist ");
 INSERT INTO Sleep (id_choice, choice, message) VALUES (5, "Launch a Movie", "Choose what you want from our Movie playlist ");

 INSERT INTO Shower (id_choice, choice, message) VALUES (1, "Warming Water", "You can take your shower after 3 min");
 INSERT INTO Shower (id_choice, choice, message) VALUES (2, "Check Towels", "You will find four clean Towels in the closet");
 INSERT INTO Shower (id_choice, choice, message) VALUES (3, "Check shampoo", "You will find two you need in the closet");


 INSERT INTO Eat (id_choice, choice, message) VALUES (1, "Show Menu of the day", "We will send you our daily Menu after 10 seconde");
 INSERT INTO Eat (id_choice, choice, message) VALUES (2, "Send Recomendation of favorite food", "Please , Pricise Your favourite Meals");
 INSERT INTO Eat (id_choice, choice, message) VALUES (3, "Reserve a table", "We will check for you an empty place ");
 INSERT INTO Eat (id_choice, choice, message) VALUES (4, "Set a reminder of the upcoming meal", "Done !");


 INSERT INTO Walk (id_choice, choice, message) VALUES (1, "Chek the weather", "We will send you all the informations about today weather");
 INSERT INTO Walk (id_choice, choice, message) VALUES (2, "Check Entertaiment shows schedule", "We will send you a list for our activity and events of the week");
 INSERT INTO Walk (id_choice, choice, message) VALUES (3, "Check hotel bar menu", "We will send you our daily Menu after 10 seconde");
 INSERT INTO Walk (id_choice, choice, message) VALUES (4, "Arcade games", "Done");
 INSERT INTO Walk (id_choice, choice, message) VALUES (5, "Reading", "We will send yo all the books name in our library");