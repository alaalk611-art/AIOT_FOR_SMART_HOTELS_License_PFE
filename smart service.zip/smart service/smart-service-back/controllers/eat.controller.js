var db = require("../database-mysql")






const getEatchoice = (req, res) => { // const id=req.params.id
    console.log(req.params.id)
        const eatChoice = `SELECT * FROM Eat `;
        db.query(eatChoice, (err, data) => {
            if (err) {
                res.send(err);
                console.log(err)
            } else {
                res.send(data);
            }
        });
    };
const getEatanswer = (req, res) => { // const id=req.params.id
    console.log(req.params.id)
        const eatanswer = `SELECT * FROM Eat WHERE id_choice = ${req.params[`id`]}`;
        db.query(eatanswer, (err, data) => {
            if (err) {
                res.send(err);
                console.log(err)
            } else {
                res.send(data);
            }
        });
    };




    module.exports={getEatchoice,getEatanswer}
