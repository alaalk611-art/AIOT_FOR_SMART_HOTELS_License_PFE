var db = require("../database-mysql")
const getShowerchoice = (req, res) => { // const id=req.params.id
    console.log(req.params.id)
        const ShowerChoice = `SELECT * FROM Shower `;
        db.query(ShowerChoice, (err, data) => {
            if (err) {
                res.send(err);
                console.log(err)
            } else {
                res.send(data);
            }
        });
    };
const getShoweranswer = (req, res) => { // const id=req.params.id
    console.log(req.params.id)
        const Showeranswer = `SELECT * FROM Shower WHERE id_choice = ${req.params[`id`]}`;
        db.query(Showeranswer, (err, data) => {
            if (err) {
                res.send(err);
                console.log(err)
            } else {
                res.send(data);
            }
        });
    };




    module.exports={getShowerchoice,getShoweranswer}
