var db = require("../database-mysql")
const getSleepchoice = (req, res) => { // const id=req.params.id
    console.log(req.params.id)
        const SleepChoice = `SELECT * FROM Sleep `;
        db.query(SleepChoice, (err, data) => {
            if (err) {
                res.send(err);
                console.log(err)
            } else {
                res.send(data);
            }
        });
    };
const getSleepanswer = (req, res) => { // const id=req.params.id
    console.log(req.params.id)
        const Sleepanswer = `SELECT * FROM Sleep WHERE id_choice = ${req.params[`id`]}`;
        db.query(Sleepanswer, (err, data) => {
            if (err) {
                res.send(err);
                console.log(err)
            } else {
                res.send(data);
            }
        });
    };




    module.exports={getSleepchoice,getSleepanswer}
