var db = require("../database-mysql")
const getWalkchoice = (req, res) => { // const id=req.params.id
    console.log(req.params.id)
        const WalkChoice = `SELECT * FROM Walk `;
        db.query(WalkChoice, (err, data) => {
            if (err) {
                res.send(err);
                console.log(err)
            } else {
                res.send(data);
            }
        });
    };
const getWalkanswer = (req, res) => { // const id=req.params.id
    console.log(req.params.id)
        const Walkanswer = `SELECT * FROM Walk WHERE id_choice = ${req.params[`id`]}`;
        db.query(Walkanswer, (err, data) => {
            if (err) {
                res.send(err);
                console.log(err)
            } else {
                res.send(data);
            }
        });
    };




    module.exports={getWalkchoice,getWalkanswer}
