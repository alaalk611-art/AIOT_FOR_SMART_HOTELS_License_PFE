const express = require("express");
const cors = require ('cors')
const itemRoutes = require('./routes/item.routes')
const eatRoutes = require("./routes/eat.routes")
const showerRoutes=require("./routes/shower.routes")
const sleepRoutes=require("./routes/sleep.routes")
const userRoutes =require("./routes/users.routes")
const walkRoutes =require("./routes/walk.routes")
const db = require('./database-mysql');
// TODO: Update this
// UNCOMMENT THE DATABASE YOU'D LIKE TO USE
 var items = require('./database-mysql');
 var eat = require('./database-mysql');
 var sleep = require('./database-mysql');
 var shower = require('./database-mysql');
 var walk = require('./database-mysql');
 var users=require("./database-mysql")
// var items = require('./database-mongo');

const app = express();
const PORT = process.env.PORT || 3000


app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(__dirname + "/../client/public"));
app.use(cors())


app.use("/api/items", itemRoutes);
app.use("/api/eat", eatRoutes);
app.use("/api/shower", showerRoutes);
app.use("/api/sleep", sleepRoutes);
app.use("/api/user", userRoutes);
app.use("/api/walk", walkRoutes);

app.listen(PORT, function () {
  console.log("listening on port 3000!");
});
